© Cypress Semiconductor Corporation, 2018-2020. This document is the property of Cypress Semiconductor Corporation and its
subsidiaries, including Spansion LLC (“Cypress”).  This document, including any software or firmware included or referenced in this
document (“Software”), is owned by Cypress under the intellectual property laws and treaties of the United States and other countries
worldwide.  Cypress reserves all rights under such laws and treaties and does not, except as specifically stated in this paragraph, grant
any license under its patents, copyrights, trademarks, or other intellectual property rights.  If the Software is not accompanied by a
license agreement and you do not otherwise have a written agreement with Cypress governing the use of the Software, then Cypress
hereby grants you a personal, non-exclusive, nontransferable license (without the right to sublicense) (1) under its copyright rights in
the Software (a) for Software provided in source code form, to modify and reproduce the Software solely for use with Cypress hardware
products, only internally within your organization, and (b) to distribute the Software in binary code form externally to end users (either
directly or indirectly through resellers and distributors), solely for use on Cypress hardware product units, and (2) under those claims of
Cypress’s patents that are infringed by the Software (as provided by Cypress, unmodified) to make, use, distribute, and import the
Software solely for use with Cypress hardware products.  Any other use, reproduction, modification, translation, or compilation of the
Software is prohibited. 
TO THE EXTENT PERMITTED BY APPLICABLE LAW, CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
WITH REGARD TO THIS DOCUMENT OR ANY SOFTWARE OR ACCOMPANYING HARDWARE, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. To the extent permitted
by applicable law, Cypress reserves the right to make changes to this document without further notice. Cypress does not assume any
liability arising out of the application or use of any product or circuit described in this document.  Any information provided in this
document, including any sample design information or programming code, is provided only for reference purposes.  It is the
responsibility of the user of this document to properly design, program, and test the functionality and safety of any application made of
this information and any resulting product.  Cypress products are not designed, intended, or authorized for use as critical components in
systems designed or intended for the operation of weapons, weapons systems, nuclear installations, life-support devices or systems, 
other medical devices or systems (including resuscitation equipment and surgical implants), pollution control or hazardous substances
management, or other uses where the failure of the device or system could cause personal injury, death, or property damage
(“Unintended Uses”).  A critical component is any component of a device or system whose failure to perform can be reasonably
expected to cause the failure of the device or system, or to affect its safety or effectiveness.  Cypress is not liable, in whole or in part,
and you shall and hereby do release Cypress from any claim, damage, or other liability arising from or related to all Unintended Uses of
Cypress products.  You shall indemnify and hold Cypress harmless from and against all claims, costs, damages, and other liabilities,
including claims for personal injury or death, arising from or related to any Unintended Uses of Cypress products. 
Cypress, the Cypress logo, Spansion, the Spansion logo, and combinations thereof, WICED, PSoC, CapSense, EZ-USB, F-RAM, and
Traveo are trademarks or registered trademarks of Cypress in the United States and other countries.  For a more complete list of
Cypress trademarks, visit cypress.com.  Other names and brands may be claimed as property of their respective owners. 
 

Cypress KitProg3 Firmware(FW) Loader
-----------------------------------

The FW Loader: 
- upgrades the KitProg3 and DAPLink application on Cypress kits
- allows switching KitProg firmware between legacy KitProg2 and current KitProg3.

It is a command-line tool run from a terminal application. 

Command-line Options

No arguments, --help or /? – Displays the list of supported commands with their descriptions.

--device-list – Displays the list of connected devices in "KitProg<X> <mode>-<ID> FW Version <FW Version>" format:
	X = 1, 2, 3 or future revisions
	mode = Bootloader, CMSIS-DAP HID, CMSIS-DAP BULK, DAPLink CMSIS-DAP.
	ID = mode appropriate ID
	FW Version = the version of the KitProgX being run.

--update-kp3 [device-name|all] – updates FW of the device with a specified name to KitProg3.
    The device name is taken from the "--device-list" command.
    The device name can be skipped if only one KitProg device is connected to the PC.
    To update FW of all the connected KitProg devices use 'all' specifier.

--update-kp2 [device-name|all] – updates FW of the device with a specified name to KitProg2
    The device name is taken from the "--device-list" command.
    The device name can be skipped if only one KitProg device is connected to the PC.
    To update FW of all the connected KitProg devices use 'all' specifier.

--mode <mode> [device-name] - switches mode of the KitProg3 device with specified name.
    The supported modes are: 'kp3-hid', 'kp3-bulk', 'kp3-bootloader', 'kp3-daplink'.
    The device name is taken from the "--device-list" command.
    The device name can be skipped if only one KitProg device is connected to the PC.
    
Notes 
1.  KitProg2 supports two modes: CMSIS-DAP and Proprietary. Only the Proprietary 
    mode supports the bootloader and therefore only in this mode is KitProg2 visible to the FW-loader. Use the Mode Switch button to switch KitProg2 to Proprietary mode.
 
2.  MiniProg4 does not support KitProg2 FW 
    The following symptoms show that KitProg2 FW is installed on MiniProg4:
    - The device is detected as MiniProg4 but doesn't operate.
    - Errors are observed while performing the --device-list command:
        - Error =  Timeout of Response read for '0x90' command. Num attempts = '2'
        - Error =  Out Endpoint is not found

    If KitProg2 FW is installed on MiniProg4, to restore device functionality:
        1. Switch the device to Bootloader mode:
            - unplug MiniProg4 from the USB
            - while pressing the Mode Select button, plug in the USB cable
            - the Mode LED blinks to indicate the kit is in Bootloader mode
            - release the button
        2. Perform the "--update-kp3" command as described above.
    
3.  On a Linux machine, run the udev_rules\install_rules.sh script before the first run 
    of the FW loader.

4. Part of FW-Loader Open Source – FOSS Packages are located on the 
   https://www.cypress.com/documentation/software-and-drivers/modustoolbox-foss-packages